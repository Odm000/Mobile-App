import { IonContent, IonHeader, IonLabel, IonPage, IonTitle, IonToolbar,IonImg, IonButton,IonFooter,IonIcon, IonSearchbar} from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab2.css';
import { ellipse, heart, home, library, person, square, triangle } from 'ionicons/icons';
import { useHistory } from 'react-router';
import { Route, Redirect } from 'react-router';
import { useState } from 'react';

const Tab2: React.FC = () => {

  const [search, setSearch] = useState('');
  const history = useHistory();

  const btnsearch = () => {
    if (search === 'The Galaxy' || search == 'the galaxy') {
      history.push('/tab5');
      
    } 
     else {
      alert('Book not found!');
    }
  };
  
  return (
    <IonPage className='page'>
      <IonHeader className='headnav' color='gradient'>
        <IonToolbar >
          <div className='top'>
          <IonSearchbar className='search'  placeholder='Search a book' value={search} 
          onIonChange={(e) => setSearch(e.detail.value!)}></IonSearchbar>
          <IonButton className='btnsearch' color='white' shape='round' onClick={btnsearch}>Search</IonButton>
          </div>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen={true} className='IonPadding'>
        <div>
          <IonImg className='headbook' src="assets\img\the-fifth.jpg"/>
          <a href='tab4'>
          <IonButton className='read' color="#fff">Start Reading</IonButton><br/>
          </a>
        </div>
        <br/>
        <IonLabel className='home'>Trends</IonLabel>
        <div className='wrapper'>
        <a className='title' href='tab3'>
        <IonImg className='book' src="assets\img\book2.jpg"/>
        </a>
        <IonImg className='book' src="assets\img\book4.jpg"/>
        <IonImg className='book' src="assets\img\book5.jpg"/>
        <IonImg className='book' id="circe" src="assets\img\circe.jpg"/>
        </div>
        <IonLabel className='home'>Sci-Fi</IonLabel>
        <div className='wrapper2'>
        <IonImg className='book2' src="assets\img\book3.png"/>
        <IonImg className='book2' src="assets\img\gulliver-s-travel.jpg"/>
        <IonImg className='book2' src="assets\img\peterpan.jpg"/>
        <IonImg className='book2' src="assets\img\marthawells.jpg"/>
        <IonImg className='book2' src="assets\img\redirising.jpg"></IonImg>
        <IonImg className='book2' src="assets\img\strange.jpg"></IonImg>
        <IonImg className='book2' src="assets\img\thegalaxy.jpg"></IonImg>
        <IonImg className='book2' src="assets\img\thestand.jpg"></IonImg>
        </div>
        <label className='home'>Horror</label>
        <div className='wrapper2'>
        <IonImg className='book2' src="assets\img\hiddenpictures.jpg"/>
        <IonImg className='book2' src="assets\img\Mexican-Gothic.jpg"/>
        <IonImg className='book2' src="assets\img\MyHeartisaChainsaw.jpg"/>
        <IonImg className='book2' src="assets\img\thebookofaccidents.jpg"/>
        </div>
      </IonContent>
      <IonFooter className='navi' >
        <IonToolbar>
          <IonTitle>
            <div className='navbar'>
             
            <IonIcon  className='nav1' icon={home}/>
           <a href="library">
           <IonIcon className='nav4' icon={library}/>
           </a>
           <a href='favs'>
            <IonIcon className='nav2' icon={heart}/>
            </a> 
            <a href='account'>
            <IonIcon className='nav3' icon={person}/>
            </a>
            </div>
          </IonTitle>
        </IonToolbar>
      </IonFooter>
     
    </IonPage>
  );
};

export default Tab2;
