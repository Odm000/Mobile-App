import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonImg, IonGrid, IonIcon  } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import react,  { useState} from 'react';
import { ellipse, heart, home, library, person, square, triangle, notifications, arrowBack, arrowBackCircle, help } from 'ionicons/icons';
import './Account.css';
import { Icon } from 'ionicons/dist/types/components/icon/icon';
import { queries } from '@testing-library/react';

const Account: React.FC = () => {
    const [imageSrc, setImageSrc] = useState<string | null>(localStorage.getItem('uploadedImage') || null);
  
    const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const imageBase64 = reader.result as string;
          localStorage.setItem('uploadedImage', imageBase64);
          setImageSrc(imageBase64);
        };
        reader.readAsDataURL(file);
      }
    };

  return (
    <IonPage className='page'>
      <IonHeader>
        <IonToolbar>
          <IonTitle></IonTitle>
          <a href='tab2'>
          <IonIcon className='arrowback' icon={arrowBack}></IonIcon>
          </a>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding"> 
      <div className='contain'>
        <br/>
        <br/>
        <br/>
        <br/>
      <div className='img'>
      {imageSrc && <IonImg src={imageSrc} />}
      <br/>
      </div>
      <h3 className='profname'><u>Joseph Estrada</u></h3>
      <br/>
      <p className='update'>Update profile</p>
      <input className='uploader'  type="file" accept="image/*" onChange={handleImageUpload} />
     
    </div>
       <div className='buttons'>
       <IonButton className='optbutton' color='light'  fill='solid'><IonIcon icon={notifications}></IonIcon>&nbsp;Notifications</IonButton><br/>
       <IonButton className='optbutton' color='light' fill='solid'> <IonIcon icon={help}></IonIcon>&nbsp;help</IonButton><br/>
       <a href='tab1'>
       <IonButton className='optbutton' color='light' fill='solid'>Sign out</IonButton><br/>
       </a> 
       </div>
       <br/>
       <br/>
       <p>version 1.0.2</p>
      </IonContent>
    </IonPage>
  );
};

export default Account;
