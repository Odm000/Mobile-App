import React, { useState } from 'react';
import { IonButton, IonHeader, IonInput, IonItem, IonLabel, IonPage, IonToolbar,IonTitle, IonContent } from '@ionic/react';
import { useHistory } from 'react-router';
import './Regform.css';



const Regform = () => {
  const [firstname, setFirstname] = useState('');
  const [lastname, setLastname] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

 

  const handleRegister = () => {
    if(firstname == "" && lastname == "" && email == "" && username == ""){
     alert('Please fill in all the blanks!');
     return false;
    }
    localStorage.setItem('firstname', firstname);
    localStorage.setItem('lastname', lastname);
    localStorage.setItem('email', email);
    localStorage.setItem('username', username);
    localStorage.setItem('password', password);
    setUsername('');
    setPassword('');
    console.log("Register Complete!");
    console.log("Firstname:"+" "+firstname +" "+"Lastname:" +" "+ 
    lastname +" "+"Email:" +" "+ email +" "+'Username:' +" "+ username +" "+"Password:"+ password);
    alert('Register Complete!')
    history.push('/Tab1');
  };

  return (

    <IonPage>
        <IonHeader>
            <IonToolbar>
                <IonTitle>Register</IonTitle>
            </IonToolbar>
        </IonHeader>
        <IonContent>
     <IonItem className='text1'>
        <IonLabel position="floating">First Name:</IonLabel>
        <IonInput className='labell' type='text' value={firstname} onIonChange={(e) => setFirstname(e.detail.value!)} required></IonInput>
      </IonItem>
      <br/>
      <br/>
      <IonItem className='text1'>
        <IonLabel position="floating">Last Name:</IonLabel>
        <IonInput className='labell' value={lastname} onIonChange={(e) => setLastname(e.detail.value!)}  required></IonInput>
      </IonItem>
      <br/>
      <br/>
      <IonItem className='text1'>
        <IonLabel position="floating">Email:</IonLabel>
        <IonInput className='labell' value={email} onIonChange={(e) => setEmail(e.detail.value!)}  required></IonInput>
      </IonItem>
      <br/>
      <br/>
      <IonItem className='text1'>
        <IonLabel position="floating">Username:</IonLabel>
        <IonInput className='labell' value={username} onIonChange={(e) => setUsername(e.detail.value!)}  required></IonInput>
      </IonItem>
      <br/>
      <br/>
      <IonItem className='text1'>
        <IonLabel position="floating">Password:</IonLabel>
        <IonInput className='labell' type="password" value={password} onIonChange={(e) => setPassword(e.detail.value!)}  required></IonInput>
      </IonItem>
      <br/>
      <br/>
      <IonButton className='btnregg' onClick={handleRegister}>Register</IonButton>
      <br/>
      <a href='tab1'>
      <IonButton className='btnregg'>back</IonButton>
      </a>
      </IonContent>
      </IonPage>
  );
};

export default Regform;
