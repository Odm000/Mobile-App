import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar,IonLabel, IonImg, IonText,IonFooter, IonIcon } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import { ellipse, heart, home, library, person, square, triangle } from 'ionicons/icons';
import { Route, Redirect } from 'react-router';
import './Favs.css';

const Favs: React.FC = () => {
  return (
    <IonPage>
      <IonHeader color='#000'>
        <IonToolbar>
          <IonLabel className='favi'>Favorites</IonLabel>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
      <div className='wrap'>
        <IonImg className='ebook' src="assets\img\book1.jpg"></IonImg>
        <IonImg className='ebook' src="assets\img\book4.jpg"></IonImg>
        <IonImg className='ebook' src="assets\panagram books\CondemingTheHeavens.jpg"></IonImg>
      </div>
      <div className='wrap'>
        <IonImg className='ebook' src="assets\img\book5.jpg"></IonImg>
        <IonImg className='ebook' src="assets\img\gulliver-s-travel.jpg"></IonImg>
        <IonImg className='ebook' src="assets\panagram books\Synth..jpg"></IonImg>
      </div>
      <div className='wrap'>
        <IonImg className='ebook' src="assets\panagram books\Thechamberoftime.jpg"></IonImg>
        <IonImg className='ebook' src="assets\panagram books\walkingtoaldebaran.jpg"></IonImg>
        <IonImg className='ebook' src="assets\img\marthawells.jpg"></IonImg>
      </div>
      </IonContent>
      <IonFooter className='navi' >
        <IonToolbar>
          <IonTitle>
            <div className='navbar'>
            <a href='tab2'> 
            <IonIcon  className='navhome' icon={home}/>
            </a>
           <a href="library">
           <IonIcon className='navlibrary' icon={library}/>
           </a>
           <a href='favs'>
            <IonIcon className='navfavorites' icon={heart}/>
            </a> 

            <a href='account'>
            <IonIcon className='navaccount' icon={person}/>
            </a>
            </div>
          </IonTitle>
        </IonToolbar>
      </IonFooter>
    </IonPage>
  );
};

export default Favs;
