import { IonButton, IonCheckbox, IonContent, IonHeader, IonImg, IonInput, IonItem, IonLabel, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import { useState } from 'react';
import { useHistory } from 'react-router';
import './Tab1.css';


const Tab1: React.FC = () => {

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleLogin = () => {
    const storedUsername = localStorage.getItem('username');
    const storedPassword = localStorage.getItem('password');
  
    if(username === "" && password === storedPassword){
    alert('Please Enter Your Username or Password!');
     return false;
  }
    if (username === storedUsername && password === storedPassword) {
      alert('Login Successful!');
      console.log('Login Successful!');
      history.push('/tab2');
   
    }else {
      alert('Invalid username or password');
    }
    setUsername('');
    setPassword('');
  };


  return (
    <IonPage className='backpage'>
    <IonContent  fullscreen> 
    <IonImg className='mlogo' src="assets\img\mob-logo.png"></IonImg>
        <h2>Panagram</h2>
      <IonItem class="txt1">
      <IonLabel></IonLabel>
<IonInput className='label' placeholder="Username" value={username}
          onIonChange={(e) => setUsername(e.detail.value!)}  required></IonInput>
      </IonItem>
      <br/>
      <IonItem class="txt1">
      <IonLabel></IonLabel>
<IonInput type='password'  class="label" placeholder="Password" value={password}
          onIonChange={(e) => setPassword(e.detail.value!)}  required></IonInput>
      </IonItem>
      <br/>
      <IonButton shape='round'  color="orange"  class="btnlogin" onClick={handleLogin} >Login</IonButton>
      <br/>
      
      <a href='regform'>
      <IonButton shape='round'  color="orange"  class="btnreg"  >Register</IonButton>
      </a>
      <br/>
      <h6 className='forget'><u>Forgot your password?</u></h6>
    
      
    </IonContent>
  </IonPage>
  
);
};

export default Tab1;
