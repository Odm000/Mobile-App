import { IonContent, IonHeader, IonLabel, IonPage, IonTitle, IonToolbar,IonImg, IonButton,IonFooter,IonIcon, IonSearchbar} from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Library.css';
import { ellipse, heart, home, library, person, square, triangle } from 'ionicons/icons';
import { useHistory } from 'react-router';
import { Route, Redirect } from 'react-router';
import { useState } from 'react';

const Library: React.FC = () => {

  const [search, setSearch] = useState('');
  const history = useHistory();

  const btnsearch = () => {
    if (search === 'The Galaxy' || search == 'the galaxy') {
      history.push('/tab5');
      
    } 
     else {
      alert('Book not found!');
    }
  };
  
  return (
    <IonPage className='page'>
      <IonHeader className='headnav' color='gradient'>
        <IonToolbar >
          <div className='top'>
          <IonSearchbar className='search'  placeholder='Search a book' value={search} 
          onIonChange={(e) => setSearch(e.detail.value!)}></IonSearchbar>
          <IonButton className='btnsearch' color='white' shape='round' onClick={btnsearch}>Search</IonButton>
          </div>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen={true} className='IonPadding'>
        <br/>
        <IonLabel className='home'>Library</IonLabel>
        <br/>
        <br/>
        <div className='wrapper'>
        <a className='title'>
        <IonImg className='book' src="assets\panagram books\CondemingTheHeavens.jpg"/>
        </a>

        <a >
        <IonImg className='book' src="assets\panagram books\ForgedofDestiny.jpg"/>
        </a>

        <a href='/synth'>
        <IonImg className='book' src="assets\panagram books\Synth..jpg"/>
        </a>
        </div>

        <div className='wrapper'>
        <a href='/'>
        <IonImg className='book' src="assets\panagram books\Thechamberoftime.jpg"/>
        </a>

        <a href='/firstmage'>
        <IonImg className='book' src="assets\panagram books\thefirstmage.jpg"/>
        </a>

        <a >
        <IonImg className='book' src="assets\panagram books\TheGhost.jpg"/>
        </a>
        </div>

        <div className='wrapper'>
        <a href=''>
        <IonImg className='book' src="assets\img\marthawells.jpg"/>
        </a>

        <a href='/redrising'>
        <IonImg className='book' src="assets\img\redirising.jpg"></IonImg>
        </a>
        <a href='/stranger'>
        <IonImg className='book' src="assets\img\strange.jpg"></IonImg>
        </a>
        </div>

        <div className='wrapper'>
        <IonImg className='book' src="assets\img\hiddenpictures.jpg"/>
        <IonImg className='book' src="assets\img\Mexican-Gothic.jpg"/>
        <IonImg className='book' src="assets\img\MyHeartisaChainsaw.jpg"/>
        </div>

        <div className='wrapper'>
        <IonImg className='book' src="assets\panagram books\walkingtoaldebaran.jpg"/>
        <IonImg className='book' src="assets\panagram books\Twinsouls.jpg"/>
        <IonImg className='book' src="assets\panagram books\ACourtt.jpg"/>
        </div>
        <div className='wrapper'>
        <IonImg className='book' src="assets\img\book2.jpg"/>
        <IonImg className='book' src="assets\img\circe.jpg"/>
        <IonImg className='book' src="assets\img\book5.jpg"/>
        </div>
        <div className='wrapper'>
        <IonImg className='book' src="assets\panagram books\War begin.jpg"/>
        <IonImg className='book' src="assets\panagram books\the eye of the God.jpg"/>
        <IonImg className='book' src="assets\panagram books\The Protocol.png"/>
        </div>
        <div className='wrapper'>
        <IonImg className='book' src="assets\panagram books\The Omega Strain.png"/>
        <IonImg className='book' src="assets\panagram books\apocalypse.jpg"/>
        <IonImg className='book' src="assets\panagram books\ashes of  the fall.jpg"/>
        </div>
        <div className='wrapper'>
        <a href='/primarytarget'>
        <IonImg className='book' src="assets\panagram books\primary target.jpg"/>
        </a>
        </div>
      </IonContent>
      <IonFooter className='navie'>
        <IonToolbar>
          <IonTitle >
            <div className='navbar'>
             <a href='tab2'>
            <IonIcon  className='navhome' icon={home}/>
            </a>
           <a href="library">
           <IonIcon className='navlibra' icon={library}/>
           </a>
           <a href='favs'>
            <IonIcon className='navfavs' icon={heart}/>
            </a> 
            <IonIcon className='navacc' icon={person}/>
            </div>
          </IonTitle>
        </IonToolbar>
      </IonFooter>
      
     
    </IonPage>
  );
};

export default Library;
